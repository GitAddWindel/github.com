import msvcrt  # For Windows-only _getch() function

def main():
    with open("data.txt", "a") as outfile:  # Open file in append mode
     

        while True:
            ch = msvcrt.getch()  # Get character without waiting for Enter

            # Handle the backspace key
            if ch == b'\x08':  # Backspace key
                outfile.seek(outfile.tell() - 1, 0)  # Move file cursor back one character
                outfile.truncate()  # Remove the last character from the file
                print("\b \b", end='', flush=True)  # Remove the last character from the console
            else:
                outfile.write(ch.decode("utf-8"))  # Write character to file
                outfile.flush()  # Ensure data is written to disk immediately
                print(ch.decode("utf-8"), end='', flush=True)  # Echo the character to the console

if __name__ == "__main__":
    main()
